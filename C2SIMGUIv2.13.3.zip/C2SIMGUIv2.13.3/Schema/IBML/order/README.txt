Schema needed for the NMSG-048 2009 Experiments.

Assembled by Sidney Chartrand from previous GMU schemas,
to apply simplifications selected by MSG-048.

Edited and given new version numbers 20 July 2009 by
Mark Pullen, in order to restore RouteWhere, which is
still needed, with its supporting RouteWhereType and
LocationType.


