The C2SIMControl is a control panel for C2SIM, intended to met the 
requirements of FMN Spiral 5 (now 6) for operational users to 
control the C2SIM environment with minmal details. It was derived
largely from the C2SIMGUI editor used for C2SIM development.

The C2SIMcontrol can be run by invoking in this directory. The first 
parameter of the command to run in the IP address of the server used.

It has a basic panel for any/all C2 users and a server control panel
for the main controller. To run the server control add two more
parameters: the password and the digit 1.

for Linux and MacOSX, on command line: ./runControl
(you may need to first run on command line "chmod +x ./runControl")

for Microsoft Windows: runC2SIMcontrol.bat

This is newly developed software so bugs can be expected.
Please report any problems to mpullen@gmu.edu and include screen shots.

